const mongoose = require('mongoose');

const InventoryItemSchema = new mongoose.Schema({
    componentType: {
        type: String,
        required: true,
        trim: true,
        // *** FIX #1: Added 'Laptop' to the list of valid device types ***
        enum: ['Monitor', 'Keyboard', 'Mouse', 'UPS', 'CPU', 'Pen Tab', 'Headphone', 'Laptop']
    },
    brand: { type: String, required: true, trim: true },
    model: { type: String, trim: true },
    serialNumber: { type: String, required: true, unique: true, trim: true },
    status: {
        type: String,
        required: true,
        enum: ['Unassigned', 'Assigned', 'In-Repair', 'Retired'],
        default: 'Unassigned'
    },
    assignedTo: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        default: null
    },
    purchaseDate: { type: Date },
    warrantyExpiry: { type: Date },
    invoiceLink: { type: String, trim: true },
    isWarrantyRegistered: { type: Boolean, default: false },
    specifications: {
        processor: String,
        graphicCard: String,
        ram: String,
        storage: String
    }
}, { timestamps: true });

module.exports = mongoose.model('InventoryItem', InventoryItemSchema);