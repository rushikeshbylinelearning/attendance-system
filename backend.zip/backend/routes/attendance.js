// backend/routes/attendance.js
const express = require('express');
const mongoose = require('mongoose');
const authenticateToken = require('../middleware/authenticateToken');
const User = require('../models/User');
const AttendanceLog = require('../models/AttendanceLog');
const AttendanceSession = require('../models/AttendanceSession');
const BreakLog = require('../models/BreakLog');

const router = express.Router();

// Helper to get or create today's attendance log
async function getOrCreateAttendanceLog(userId, date) {
    let log = await AttendanceLog.findOne({ user: userId, attendanceDate: date });
    if (log) {
        return log;
    } else {
        return await AttendanceLog.create({
            user: userId,
            attendanceDate: date,
            status: 'Present'
        });
    }
}

// GET /api/attendance/status (LOGIC REWRITTEN)
router.get('/status', authenticateToken, async (req, res) => {
    try {
        const { userId } = req.user;
        const today = new Date().toISOString().slice(0, 10);

        const user = await User.findById(userId).populate('shiftGroup').lean();
        if (!user || !user.shiftGroup) {
            return res.status(404).json({ error: 'User or user shift not found.' });
        }

        const attendanceLog = await AttendanceLog.findOne({ user: userId, attendanceDate: today });
        if (!attendanceLog) {
            return res.json({ status: 'Not Clocked In', sessions: [], breaks: [], calculatedLogoutTime: null });
        }
        
        const sessions = await AttendanceSession.find({ attendanceLog: attendanceLog._id }).sort({ startTime: 1 }).lean();
        const breaks = await BreakLog.find({ attendanceLog: attendanceLog._id }).sort({ startTime: 1 }).lean();
        
        const firstClockInSession = sessions.length > 0 ? sessions[0] : null;

        const hasActiveSession = sessions.some(s => !s.endTime);
        const hasActiveBreak = breaks.some(b => !b.endTime);
        let currentStatus = 'Not Clocked In';
        if (hasActiveBreak) currentStatus = 'On Break';
        else if (hasActiveSession) currentStatus = 'Clocked In';
        else if (sessions.length > 0) currentStatus = 'Clocked Out';
        
        // ===============================================
        // START: REWRITTEN LOGOUT TIME CALCULATION
        // ===============================================
        let calculatedLogoutTime = null;
        const shift = user.shiftGroup;
        const breakPenaltyMinutes = attendanceLog.penaltyMinutes || 0;

        // Only perform calculation if the user has actually clocked in
        if (firstClockInSession) {
            const clockInTime = new Date(firstClockInSession.startTime);

            // --- Logic for FIXED shifts ---
            if (shift.shiftType === 'Fixed' && shift.startTime && shift.endTime) {
                // 1. Establish the base times for today
                const [startH, startM] = shift.startTime.split(':').map(Number);
                const shiftStartTime = new Date(clockInTime);
                shiftStartTime.setHours(startH, startM, 0, 0);

                const [endH, endM] = shift.endTime.split(':').map(Number);
                const baseLogoutTime = new Date(clockInTime);
                baseLogoutTime.setHours(endH, endM, 0, 0);

                // 2. Calculate lateness penalty
                let latenessPenalty = 0;
                if (clockInTime > shiftStartTime) {
                    latenessPenalty = Math.round((clockInTime - shiftStartTime) / (1000 * 60));
                }

                // 3. Add total penalties to the base logout time
                const totalPenalty = latenessPenalty + breakPenaltyMinutes;
                baseLogoutTime.setMinutes(baseLogoutTime.getMinutes() + totalPenalty);
                calculatedLogoutTime = baseLogoutTime.toISOString();
            }
            // --- Logic for FLEXIBLE shifts ---
            else if (shift.shiftType === 'Flexible' && shift.durationHours) {
                // 1. Calculate total required work time in minutes
                const requiredWorkMinutes = (shift.durationHours * 60);

                // 2. Start from the clock-in time and add required work time + break penalties
                const requiredLogoutTime = new Date(clockInTime);
                requiredLogoutTime.setMinutes(requiredLogoutTime.getMinutes() + requiredWorkMinutes + breakPenaltyMinutes);
                calculatedLogoutTime = requiredLogoutTime.toISOString();
            }
        }
        // ===============================================
        // END: REWRITTEN LOGOUT TIME CALCULATION
        // ===============================================
        
        res.json({ status: currentStatus, sessions, breaks, calculatedLogoutTime });

    } catch (error) {
        console.error("Error fetching status:", error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

// POST /api/attendance/clock-in
router.post('/clock-in', authenticateToken, async (req, res) => {
    const { userId } = req.user;
    const today = new Date().toISOString().slice(0, 10);
    try {
        const attendanceLog = await getOrCreateAttendanceLog(userId, today);
        const activeSession = await AttendanceSession.findOne({ attendanceLog: attendanceLog._id, endTime: null });
        if (activeSession) {
            return res.status(400).json({ error: 'You are already clocked in.' });
        }
        const newSession = await AttendanceSession.create({ attendanceLog: attendanceLog._id, startTime: new Date() });
        res.status(201).json({ message: 'Clocked in successfully!', session: newSession });
    } catch (error) {
        console.error('Clock-in Error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// POST /api/attendance/clock-out
router.post('/clock-out', authenticateToken, async (req, res) => {
    const { userId } = req.user;
    const today = new Date().toISOString().slice(0, 10);
    try {
        const log = await AttendanceLog.findOne({ user: userId, attendanceDate: today });
        if (!log) return res.status(400).json({ error: 'Cannot find attendance log. You must clock in first.' });
        
        const activeBreak = await BreakLog.findOne({ attendanceLog: log._id, endTime: null });
        if (activeBreak) return res.status(400).json({ error: 'You must end your break before clocking out.' });

        const updatedSession = await AttendanceSession.findOneAndUpdate(
            { attendanceLog: log._id, endTime: null },
            { $set: { endTime: new Date() } },
            { new: true, sort: { startTime: -1 } }
        );

        if (!updatedSession) return res.status(400).json({ error: 'You are not currently clocked in.' });
        res.json({ message: 'Clocked out successfully!', session: updatedSession });
    } catch (error) {
        console.error('Clock-out Error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// GET /api/attendance/my-weekly-log (Corrected)
router.get('/my-weekly-log', authenticateToken, async (req, res) => {
    try {
        const { userId } = req.user;
        if (!mongoose.Types.ObjectId.isValid(userId)) {
            return res.status(400).json({ error: "Invalid user ID." });
        }

        let { startDate, endDate } = req.query;
        if (!startDate || !endDate) {
            const today = new Date();
            const firstDayOfWeek = new Date(today.setDate(today.getDate() - today.getDay()));
            const lastDayOfWeek = new Date(firstDayOfWeek);
            lastDayOfWeek.setDate(lastDayOfWeek.getDate() + 6);
            startDate = firstDayOfWeek.toISOString().slice(0, 10);
            endDate = lastDayOfWeek.toISOString().slice(0, 10);
        }
    
        const logs = await AttendanceLog.aggregate([
            {
                $match: {
                    user: new mongoose.Types.ObjectId(userId),
                    attendanceDate: { $gte: startDate, $lte: endDate }
                }
            },
            { $lookup: { from: 'attendancesessions', localField: '_id', foreignField: 'attendanceLog', as: 'sessions' } },
            { $lookup: { from: 'breaklogs', localField: '_id', foreignField: 'attendanceLog', as: 'breaks' } },
            {
                $project: {
                    _id: 1,
                    attendanceDate: 1,
                    status: 1,
                    sessions: {
                        $map: {
                            input: "$sessions", as: "s",
                            in: { startTime: "$$s.startTime", endTime: "$$s.endTime" }
                        }
                    },
                    breaks: {
                         $map: {
                            input: "$breaks", as: "b",
                            in: { startTime: "$$b.startTime", endTime: "$$b.endTime", duration: "$$b.durationMinutes", type: "$$b.breakType" }
                        }
                    }
                }
            },
            { $sort: { attendanceDate: 1 } }
        ]);
        res.json(logs);
    } catch (error) {
        console.error("Error fetching weekly log:", error);
        res.status(500).json({ error: "Internal server error." });
    }
});

module.exports = router;